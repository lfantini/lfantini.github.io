# KodeNames
A popular word game.

# Features
* ADA Compliant
* Word sets
  * Original
  * Spanish Word Set
  * 1000 most common nouns
  * Top 250 Movies
  * Custom word set (create your own!)
* Colorblind friendly Colors
* Muli-language compaitible with google translate
* Mobile friendly

# Instructions:
1. distribute website to players
2. Make sure each person uses the same SEED. This will sync your words.
3. Spymasters click on spymaster button to see key. 

# Feedback
If you have any issues or would like to request some features, please click on the issue tab and start a ticket. I will get back to you asap.

If you would like to hire me, please also send me an issue. :D 
