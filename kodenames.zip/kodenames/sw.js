var CACHE_NAME = 'cache-v1';
var urlsToCache = [
  'index.html',
  'spy.png',
  'spy-144.png',
  'styles/styles.css',
  'data/data.json',
  'scripts/data.js',
  'scripts/index.js',
  'scripts/seedrandom.js',
  'https://code.jquery.com/jquery-3.1.0.min.js'
];

self.addEventListener('install', function(event) {
  // Perform install steps
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        return cache.addAll(urlsToCache);
      })
  );  
});



self.addEventListener('fetch', function(event) {

console.log(event.request.url);

event.respondWith(

caches.match(event.request).then(function(response) {

return response || fetch(event.request);

})

);

});



self.addEventListener('activate', function(event) {
  console.log('Finally active. Ready to start serving content!');  
});
